# Ian Burke - 13122525 - 28th March 2018


"Imports"
import numpy as np 
import imutils
from skimage.transform import rotate ## Image rotation routine.
import scipy.fftpack as fft          ## Fast Fourier Transform
    


"Radon transform method - turns an image into a sinogram (not used in this file)"
def radon(image, steps):        
    #Build the Radon Transform using 'steps' projections of 'image'. 
    projections = []        ## Accumulate projections in a list.
    dTheta = -180.0 / steps ## Angle increment for rotations.
    
    for i in range(steps):
        projections.append(rotate(image, i*dTheta).sum(axis=0))
    
    return np.vstack(projections) # Return the projections as a sinogram
    


"Translate the sinogram to the frequency domain using Fourier Transform"
def build_proj_ffts(projs):
    #Build 1-d FFTs of an array of projections, each projection 1 row of the array.
    return fft.rfft(projs, axis=1)



"Filter the projections using a ramp filter"
def ramp_filter_ffts(ffts):
    #Ramp filter a 2-d array of 1-d FFTs (1-d FFTs along the rows).
    ramp = np.floor(np.arange(0.5, ffts.shape[1]//2 + 0.1, 0.5))
    return ffts * ramp

"Hamming Window Placeholder (saved to notes)"


"Return to the spatial domain using inverse Fourier Transform"
def inverse_fft_invert(operator):
    return fft.irfft(operator, axis=1)



"Reconstruct the image by back projecting the filtered projections (UNFINISHED)"
def back_project(operator):
    laminogram = np.zeros((operator.shape[1],operator.shape[1]))
    dTheta = 180.0 / operator.shape[0]
    for i in range(operator.shape[0]):
        temp = np.tile(operator[i],(operator.shape[1],1))
        temp = rotate(temp, dTheta*i)
        laminogram += temp
    return laminogram



"Import the image as a numpy array and display the original sinogram image"
print("Original Sinogram")
sinogram = imutils.imread('sinogram.png')
imutils.imshow(sinogram)



"Use the FFT to translate the sinogram to the Frequency Domain and print the output"
print("Frequency Domain representation of sinogram")
frequency_domain_sinogram = build_proj_ffts(sinogram)
imutils.imshow(frequency_domain_sinogram)



"Filter the frequency domain projections by multiplying each one by the frequency domain ramp filter"
print("Frequency domain projections multipled with a ramp filter")
filtered_frequency_domain_sinogram = ramp_filter_ffts(frequency_domain_sinogram)
imutils.imshow(filtered_frequency_domain_sinogram)



"Use the inverse FFT to return to the spatial domain"
print("Spatial domain representation of ramp filtered sinogram")
filtered_spatial_domain_sinogram = inverse_fft_invert(filtered_frequency_domain_sinogram)
imutils.imshow(filtered_spatial_domain_sinogram)



"Re-construct the original 2D image by back-projecting the filtered projections"
print("Original, reconstructed image")
reconstructed_image = back_project(filtered_spatial_domain_sinogram)
imutils.imshow(reconstructed_image)


"Hamming-Windowed Ramp Filter"
print("(Hamming-Windowed) reconstructed image")
hamming1 = filtered_frequency_domain_sinogram * np.hamming(1) #Only works if you pass it a 1
hamming2 = inverse_fft_invert(hamming1)
hammingFinal = back_project(hamming2)
imutils.imshow(hammingFinal)